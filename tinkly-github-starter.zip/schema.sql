-- Run once in Supabase SQL Editor.
create table if not exists public.puzzles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 150),
  type text not null,
  source text,
  solved_on date not null,
  solve_seconds integer check (solve_seconds is null or solve_seconds >= 0),
  rating integer not null default 0 check (rating between 0 and 5),
  notes text,
  created_at timestamptz not null default now()
);
create index if not exists puzzles_user_date_idx on public.puzzles(user_id,solved_on desc);
alter table public.puzzles enable row level security;
create policy "Users can read own puzzles" on public.puzzles for select to authenticated using ((select auth.uid()) = user_id);
create policy "Users can create own puzzles" on public.puzzles for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "Users can update own puzzles" on public.puzzles for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "Users can delete own puzzles" on public.puzzles for delete to authenticated using ((select auth.uid()) = user_id);
